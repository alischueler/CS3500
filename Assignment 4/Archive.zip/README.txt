added a test to account for bogs moves but still winning the game
added an IllegalStateException for when the readable runs out of inputs
removed the new line addition in render() and put it in the controller method
removed duplicate code from the controller to make it easier to follow
added more conditions for the toString() for drawing cards in the first line